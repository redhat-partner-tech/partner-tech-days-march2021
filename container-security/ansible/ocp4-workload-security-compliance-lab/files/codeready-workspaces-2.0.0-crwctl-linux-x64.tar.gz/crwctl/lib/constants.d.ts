declare const DEFAULT_CHE_IMAGE = "registry.redhat.io/codeready-workspaces/server-rhel8:2.0";
declare const DEFAULT_CHE_OPERATOR_IMAGE = "registry.redhat.io/codeready-workspaces/server-operator-rhel8:2.0";
export { DEFAULT_CHE_IMAGE, DEFAULT_CHE_OPERATOR_IMAGE };
